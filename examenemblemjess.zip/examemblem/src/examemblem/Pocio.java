package examemblem;

public class Pocio extends Objecte {
	
	
	public Pocio(int vit) {
		super(vit);
		
	}	
	

}
