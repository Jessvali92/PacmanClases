package examemblem;

public class Prolog extends Enemic{
	
	
	int vida= 5;
	
	public Prolog(int vida) {
		super();
		this.vida=vida;
	
	}

	public int getVida() {
		System.out.println("soy prolog");
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}
	

}
