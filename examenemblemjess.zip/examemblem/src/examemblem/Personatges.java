package examemblem;



public abstract class Personatges {
	
	protected int vidaActual;
	protected int vidaMaxima = 200;
	protected int atk;
	protected boolean estatVida= true;
	protected boolean atacar = true;
	protected String fraseataque="";
	protected String nom;
	
	public Personatges (){
	
	vidaMaxima = 200;
	atk = 1;
	estatVida= true;
	atacar = true;			
		
		
	}
	
	public Personatges (String nom){
		
		
		
		
	}
	
		
	
	public int getVidaActual() {
		return vidaActual;
	}

	public void setVidaActual(int vidaActual) {
		this.vidaActual = vidaActual;
	}

	public int getVidaMaxima() {
		return vidaMaxima;
	}

	public void setVidaMaxima(int vidaMaxima) {
		this.vidaMaxima = vidaMaxima;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public boolean isEstatVida() {
		return estatVida;
	}

	public void setEstatVida(boolean estatVida) {
		this.estatVida = estatVida;
	}

	public boolean isAtacar() {
		return atacar;
	}

	public void setAtacar(boolean atacar) {
		this.atacar = atacar;
	}

	protected void atacar (Personatges a) {
		
		if (this.estatVida=true) {
		System.out.println("est� atacando " + this.fraseataque+"!!!");
		int resta = this.vidaActual-a.atk;
		System.out.println("la vida del enemigo ahora es " + resta);
		if (this.vidaActual<0) {
			a.morirse();
		}
		}else {
			System.out.println("no puedes atacar muerto");
		}
	}

	private void morirse () {
		this.estatVida=false;
		System.out.println("muerto");
		atacar= false;
	}
	
	
	/*private String visualitazar  (Personatges a) {
			
		}*/

}
