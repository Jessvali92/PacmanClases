package examemblem;

public class Marc extends Aliat {
	
	
	private String uni = "UPC";
	
	
	public Marc(String nom) {
		super(nom);
		atk = 10;
		vidaActual = 100;
		fraseataque="Marc,Sr ingenieeeer";
		
	}

	public String getUni() {
		System.out.println("hola UPC");
		return uni;
	}


	public void setUni(String uni) {
		this.uni = uni;
	}	
	
	

}
