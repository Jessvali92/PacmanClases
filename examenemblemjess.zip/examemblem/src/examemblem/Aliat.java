package examemblem;

public class Aliat extends Personatges {
	
	
	protected String nom;
	public boolean objecte = true;
	
	
	
	public Aliat (String nom) {
		super();
		this.nom = nom;
		
		
	}
	
	
	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public boolean isObjecte() {
		return objecte;
	}


	public void setObjecte(boolean objecte) {
		this.objecte = objecte;
	}


	public Personatges object(){
		
		if (estatVida) {
			System.out.println("se puede atacar");
			return null;
			
		}else
			return null;
		
		
	}
	
	protected void usarobj (Objecte o) {
		
		System.out.println("uso obj ");
		int resultpoti = this.vidaActual+(o.getVit());
		if(this.vidaMaxima<this.vidaActual)this.vidaActual=this.vidaMaxima;
		System.out.println("ahora tienes mas vida " + resultpoti);
		
		}		
}
