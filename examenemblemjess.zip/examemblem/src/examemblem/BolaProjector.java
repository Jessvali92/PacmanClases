package examemblem;

public class BolaProjector extends Enemic {
	
	public BolaProjector() {
		super();
	}
	
	
	
	
	
	
	

}
