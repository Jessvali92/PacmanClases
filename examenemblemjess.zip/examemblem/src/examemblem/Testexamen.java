package examemblem;

public class Testexamen {

	public static void main(String[] args) {
		
		
		Marc marc = new Marc("nombreMarc"); 
		Gatet aki = new Gatet("nombreMarc"); 
		
		marc.getUni();
		aki.getNom();
		
		System.out.println("ataque marc a gato ");
		
		marc.atacar(aki);
		
		System.out.println("ataque gato a marc ");
		
		aki.atacar(marc);	

	}

}
