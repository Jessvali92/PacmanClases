package examemblem;

public class Pergami extends Objecte {

	
	public Pergami(int vit) {
		super(vit);
		
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
