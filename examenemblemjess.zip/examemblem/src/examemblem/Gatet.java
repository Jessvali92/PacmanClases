package examemblem;

public class Gatet extends Aliat {
	
	
	private String varietatPeix= "salmon";
	
	
	
	
	public String getVarietatPeix() {
		System.out.println("pez si");
		return varietatPeix;
	}




	public void setVarietatPeix(String varietatPeix) {
		this.varietatPeix = varietatPeix;
	}




	public Gatet(String nom) {
		super(nom);
		atk = 20;
		vidaActual = 100;
		fraseataque="marramiau";
		
	}	

}
