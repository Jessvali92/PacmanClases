package examemblem;

import java.util.ArrayList;

public class Enemic extends Personatges{
	
	
	private int nivellOdi;
	
	public Enemic(int nivellOdi) {
		super();
		this.nivellOdi = nivellOdi;
		
		

	}
	public Enemic() {
		super();	
		

	}
	
	


}
