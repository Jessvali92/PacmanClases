import java.util.ArrayList;

public class Fantasma {
	
	
	private Integer posX;
	private Integer posY;
	private Boolean movDone = false;
	private Boolean firstTime = false;
	private Boolean die = false;
	private int lastNumber = 20;
	private int tiempobolagorda = 0;
	private int imgAR;
	private int imgAB;
	private int imgI;
	private int imgD;
	static ArrayList<Integer> ghostWall = new ArrayList<Integer>();
	static boolean red = false;
	
	
		/*	 "rojoAR.png","rojoAB.png","rojoI.png","RojoD.png",//3,4,5,6 ROJO
		        
		        "celesteAR.png","celesteAB.png","celesteI.png","celesteD.png",//7,8,9,10 CELESTE
		        
		        "rosadoAR.png","rosadoAB.png","rosadoI.png","rosadoD.png",//11,12,13,14 ROSADO
		        
		        "naranjaAR.png","naranjaAB.png","naranjaI.png","naranjaD.png",//15,16,17,18 NARANJA*/

	public void initGhostWall() {
		for (int i=3; i<18;i++) {
			ghostWall.add(i);
		}
	}
	
	public Fantasma() { // en caso de usar fantasma sin posiciones-imagenes
		initGhostWall();
	}
	
	public Fantasma(Integer posicionX,Integer posicionY, int AR, int AB, int I, int D, int lastNumber) {

		initGhostWall();
		this.posX = posicionX;
		this.posY = posicionY;
		imgAR = AR;
		imgAB = AB;
		imgI = I;
		imgD = D;
		this.lastNumber = lastNumber;
		
	}

	public Integer getPosX() {
		return posX;
	}
	
	
	public void setPosX(Integer posicionX) {
		this.posX = posicionX;
	}
	public Integer getPosY() {
		return posY;
	}
	public void setPosY(Integer posicionY) {
		this.posY = posicionY;
	}
	
	public Boolean getMovDone() {
		return this.movDone;
	}
	
	public void setMovDone(Boolean movDone) {
		this.movDone = movDone;
	}


	public void operaPos(String operacion,String variable) {
		if(operacion.equals("-")) {
			if(variable.equals("x")) {
				this.posX--;
			}else if(variable.equals("y")){
				this.posY--;
			}
		}else if(operacion.equals("+")){
			if(variable.equals("x")) {
				this.posX++;
			}else if(variable.equals("y")){
				this.posY++;
			}
		}
	}

	public Boolean getFirstTime() {
		
		return this.firstTime;
	}
			
		

	public void setFirstTime(Boolean firstTime) {
		this.firstTime = firstTime;
	}

	public boolean getDie() {
		
		return die;
	}

	public void setDie(Boolean die) {
		this.die = die;
	}

	public void hazLoTuyo() {
		// TODO Auto-generated method stub
		
		this.move();
		this.know();
		
	}

	private void know() {
		
		if(die) {
			tiempobolagorda++;
			if (tiempobolagorda>30) {
				die=false;
				tiempobolagorda=0;
				//System.out.println(tiempobolagorda);
	    	}
			
			if (posX==Pacman.pacx && posY==Pacman.pacy) {
				
				//Se comen al fantasma, ya lo haras.
			}
			
		}else {
			if (posX==Pacman.pacx && posY==Pacman.pacy) {

				Pacman.finjuego = true;
				Pacman.fin = true;
			}
		}		
	}
	
	private void returnHome () {
		
		int x = getPosX();
		int y = getPosY();
		
		if (x<posicionCasaX){
			setPosX();
			
		}else{ 
			
		}
				
		//saber si hay que ir hacia la derecha/izquierda o arriba/abajo
		/*
		 * x=5
		 * y=5
		 * posicionCasaX = 14
		 * posicionCasaY = 11
		 * 
		 * if (x<posicionCasaX){
		 * 		tiene que ir filas++
		 * }else{ //seria mas grande X=15
		 * 		tiene que ir a filas-- 
		 * }
		 * 
		 * if (y<posicionCasaY){
		 * 		tiene que ir columnas++
		 * }else{ //seria mas grande X=15
		 * 		tiene que ir a columnas-- 
		 * }
		 * 
		 * Comprobar que las 2 casillas adyacentes esten vacias en horizontal (0 o 22)
		 * Lo mismo en vertical
		 * El que cumpla dos casillas vacias adyacentes mover hasta una pared en H o V
		 * 
		 * hacer un while que pida la posicion de X/Y y que no pare de moverse
		 * los ojos hasta que no llegue a la posici�n casa 14/11
		 * 
		 * casillas de alrededor
		 * si es 3 o mas es un cruce
		 * 
		 * 
		 */
		
		
		
	}
	
	private void move() {
		
		Pacman.map[posX][posY] = lastNumber;
		movDone=false;
		while (!movDone) {
			int movF = (int) (Math.random() * (4) + 1);		
			switch (movF) {
				case 1: //DOWN MOV
					if (Pacman.map[this.getPosX() + 1][this.getPosY()] != 1
							&& Pacman.map[this.getPosX() + 1][this.getPosY()] != 22
							&& !ghostWall.contains(Pacman.map[this.getPosX() + 1][this.getPosY()])) { //can he move down?
						
						this.operaPos("+", "x");
						lastNumber = Pacman.map[this.getPosX()][this.getPosY()];
						//DEATH
						if (this.getDie() == true) {
							Pacman.map[this.getPosX()][this.getPosY()] = 28;
							this.setMovDone(true);
							if (posX==Pacman.pacx && posY==Pacman.pacy) {
								Pacman.map[this.getPosX()][this.getPosY()] = 14;// el 14 es el rosa Cambiar cuando se pueda
								returnHome();
							}
							
						//ALIVE		
						} else if (this.getDie() == false) {
							Pacman.map[this.getPosX()][this.getPosY()] = imgAB;
							this.setMovDone(true);
						}else {
							this.setMovDone(true);
							
						}
					}
					break;
				
				case 2: // UP MOV
					if (Pacman.map[this.getPosX() - 1][this.getPosY()] != 1
							&& !ghostWall.contains(Pacman.map[this.getPosX() - 1][this.getPosY()])) {//can he move up?
						
						this.operaPos("-", "x");
						lastNumber = Pacman.map[this.getPosX()][this.getPosY()];					
						//DEATH							
						if (this.getDie() == true) {
							Pacman.map[this.getPosX()][this.getPosY()] = 28;
							this.setMovDone(true);
							if (posX==Pacman.pacx && posY==Pacman.pacy) {
								returnHome();
							}
						//ALIVE
	
						} else if (this.getDie() == false) {
							Pacman.map[this.getPosX()][this.getPosY()] = imgAR;
							this.setMovDone(true);
						}else {
							this.setMovDone(true);
							
						}
					}
					break;				
				case 3: // LEFT MOV
					if (Pacman.map[this.getPosX()][this.getPosY() - 1] != 1
							&& Pacman.map[this.getPosX()][this.getPosY() - 1] != 22
							&& !ghostWall.contains(Pacman.map[this.getPosX()][this.getPosY() - 1])) {//can he move left?
						
						this.operaPos("-", "y");
						lastNumber = Pacman.map[this.getPosX()][this.getPosY()];
						//DEATH
						if (this.getDie() == true) {
							Pacman.map[this.getPosX()][this.getPosY()] = 28;
							this.setMovDone(true);
							if (posX==Pacman.pacx && posY==Pacman.pacy) {
								returnHome();
							}
						//ALIVE
						} else if (this.getDie() == false) {
	
							Pacman.map[this.getPosX()][this.getPosY()] = imgI;
							this.setMovDone(true);
					}else {
						this.setMovDone(true);
					}					
					}
					break;
				case 4: // RIGHT MOV
					if (Pacman.map[this.getPosX()][this.getPosY() + 1] != 1
							&& Pacman.map[this.getPosX()][this.getPosY() + 1] != 22
							&& !ghostWall.contains(Pacman.map[this.getPosX()][this.getPosY() + 1])) {//can he move right?
	
						this.operaPos("+", "y");
						lastNumber = Pacman.map[this.getPosX()][this.getPosY()];
						//DEATH							
						if (this.getDie() == true) {
							Pacman.map[this.getPosX()][this.getPosY()] = 28;
							this.setMovDone(true);
							if (posX==Pacman.pacx && posY==Pacman.pacy) {
								returnHome();
							}
						//ALIVE
						} else if (this.getDie() == false) {
							Pacman.map[this.getPosX()][this.getPosY()] = imgD;
							this.setMovDone(true);		
						}else {
							this.setMovDone(true);					
						}											
					}
					break; 
			}
		}
	}

}
